package me.Sabu.trailsgui.events;

public class Movement {

}
